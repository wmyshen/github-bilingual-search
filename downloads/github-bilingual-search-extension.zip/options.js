Object.fromEntries([
  ["本地知识库", "local knowledge base"],
  ["密码管理器", "password manager"],
  ["截图工具", "screenshot tool"],
  ["笔记软件", "note taking"],
  ["任务管理", "task manager"],
  ["待办事项", "todo"],
  ["时间追踪", "time tracking"],
  ["文件同步", "file sync"],
  ["文件管理器", "file manager"],
  ["网盘", "cloud storage"],
  ["下载工具", "download manager"],
  ["下载器", "downloader"],
  ["视频下载", "video downloader"],
  ["音乐播放器", "music player"],
  ["视频播放器", "video player"],
  ["图片压缩", "image compression"],
  ["图片编辑", "image editor"],
  ["录屏工具", "screen recorder"],
  ["剪贴板管理", "clipboard manager"],
  ["远程桌面", "remote desktop"],
  ["思维导图", "mind map"],
  ["流程图", "flowchart"],
  ["电子书阅读器", "ebook reader"],
  ["翻译工具", "translator"],
  ["文字识别", "OCR"],
  ["语音识别", "speech recognition"],
  ["语音合成", "text to speech"],
  ["聊天机器人", "chatbot"],
  ["机器学习框架", "machine learning framework"],
  ["深度学习", "deep learning"],
  ["向量数据库", "vector database"],
  ["数据库管理", "database management"],
  ["数据库客户端", "database client"],
  ["接口测试", "API testing"],
  ["负载测试", "load testing"],
  ["性能监控", "performance monitoring"],
  ["日志管理", "log management"],
  ["网站分析", "web analytics"],
  ["静态博客", "static blog"],
  ["静态网站生成器", "static site generator"],
  ["文档生成器", "documentation generator"],
  ["低代码平台", "low code"],
  ["自动化工作流", "workflow automation"],
  ["爬虫框架", "web scraping framework"],
  ["浏览器自动化", "browser automation"],
  ["单元测试", "unit testing"],
  ["代码编辑器", "code editor"],
  ["终端模拟器", "terminal emulator"],
  ["反向代理", "reverse proxy"],
  ["内网穿透", "reverse tunnel"],
  ["个人知识管理", "personal knowledge management"],
  ["本地大模型", "local LLM"],
  ["文档问答", "document RAG"],
  ["备份工具", "backup"],
  ["书签管理", "bookmark manager"],
  ["自托管", "self hosted"]
]);
function endpoint(base) {
  const u = new URL(base.trim());
  if (u.protocol !== "https:" || u.username || u.password || u.search || u.hash) throw new Error("Base URL 必须是无账号、查询参数的 HTTPS 地址。");
  u.pathname = u.pathname.replace(/\/$/, "") + "/chat/completions";
  return u;
}
const byId = (id) => document.getElementById(id);
const input = (id) => byId(id);
async function rpc(type, data = {}) {
  const r = await chrome.runtime.sendMessage({ type, ...data });
  if (!(r == null ? void 0 : r.ok)) throw new Error((r == null ? void 0 : r.error) || "扩展未响应。");
  return r.data;
}
function status(text, error = false) {
  byId("status").textContent = text;
  byId("status").className = error ? "error" : "";
}
async function load() {
  var _a, _b, _c;
  const r = await rpc("config");
  input("base").value = ((_a = r.config) == null ? void 0 : _a.base) || "";
  input("model").value = ((_b = r.config) == null ? void 0 : _b.model) || "";
  input("remember").checked = !!((_c = r.config) == null ? void 0 : _c.remember);
  input("key").value = "";
  byId("key-state").textContent = r.hasKey ? "已保存密钥，留空表示保留。" : "尚未保存密钥，词库搜索仍可使用。";
}
async function action(fn) {
  const buttons = [...document.querySelectorAll("button")];
  buttons.forEach((b) => b.disabled = true);
  try {
    await fn();
  } catch (e) {
    status(e instanceof Error ? e.message : "操作失败。", true);
  } finally {
    buttons.forEach((b) => b.disabled = false);
  }
}
byId("settings").onsubmit = (e) => {
  e.preventDefault();
  void action(async () => {
    const url = endpoint(input("base").value);
    if (!await chrome.permissions.request({ origins: [url.origin + "/*"] })) throw new Error("未授权接口域名，配置未保存。");
    await rpc("save", { base: input("base").value, model: input("model").value, key: input("key").value, remember: input("remember").checked });
    await load();
    status("已保存。返回 GitHub 搜索页并刷新即可使用。");
  });
};
byId("test").onclick = () => void action(async () => {
  status("正在测试已保存的配置…");
  const r = await rpc("test");
  status("连接成功，测试转换结果：" + r.english);
});
byId("cache").onclick = () => void action(async () => {
  await rpc("clearCache");
  status("缓存已清除。");
});
byId("clear").onclick = () => void action(async () => {
  await rpc("clear");
  await load();
  status("配置、密钥、缓存和可选接口权限已清除。");
});
void load().catch((e) => status(String(e), true));

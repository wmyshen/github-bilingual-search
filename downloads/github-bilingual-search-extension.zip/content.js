var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
(function() {
  "use strict";
  Object.fromEntries([
    ["本地知识库", "local knowledge base"],
    ["密码管理器", "password manager"],
    ["截图工具", "screenshot tool"],
    ["笔记软件", "note taking"],
    ["任务管理", "task manager"],
    ["待办事项", "todo"],
    ["时间追踪", "time tracking"],
    ["文件同步", "file sync"],
    ["文件管理器", "file manager"],
    ["网盘", "cloud storage"],
    ["下载工具", "download manager"],
    ["下载器", "downloader"],
    ["视频下载", "video downloader"],
    ["音乐播放器", "music player"],
    ["视频播放器", "video player"],
    ["图片压缩", "image compression"],
    ["图片编辑", "image editor"],
    ["录屏工具", "screen recorder"],
    ["剪贴板管理", "clipboard manager"],
    ["远程桌面", "remote desktop"],
    ["思维导图", "mind map"],
    ["流程图", "flowchart"],
    ["电子书阅读器", "ebook reader"],
    ["翻译工具", "translator"],
    ["文字识别", "OCR"],
    ["语音识别", "speech recognition"],
    ["语音合成", "text to speech"],
    ["聊天机器人", "chatbot"],
    ["机器学习框架", "machine learning framework"],
    ["深度学习", "deep learning"],
    ["向量数据库", "vector database"],
    ["数据库管理", "database management"],
    ["数据库客户端", "database client"],
    ["接口测试", "API testing"],
    ["负载测试", "load testing"],
    ["性能监控", "performance monitoring"],
    ["日志管理", "log management"],
    ["网站分析", "web analytics"],
    ["静态博客", "static blog"],
    ["静态网站生成器", "static site generator"],
    ["文档生成器", "documentation generator"],
    ["低代码平台", "low code"],
    ["自动化工作流", "workflow automation"],
    ["爬虫框架", "web scraping framework"],
    ["浏览器自动化", "browser automation"],
    ["单元测试", "unit testing"],
    ["代码编辑器", "code editor"],
    ["终端模拟器", "terminal emulator"],
    ["反向代理", "reverse proxy"],
    ["内网穿透", "reverse tunnel"],
    ["个人知识管理", "personal knowledge management"],
    ["本地大模型", "local LLM"],
    ["文档问答", "document RAG"],
    ["备份工具", "backup"],
    ["书签管理", "bookmark manager"],
    ["自托管", "self hosted"]
  ]);
  const hasChinese = (s) => new RegExp("\\p{Script=Han}", "u").test(s);
  function parseQuery(q) {
    if (q.length > 500) throw new Error("查询过长，请缩短到 500 字以内。");
    if (/["'()]/.test(q) || /(?:^|\s)(AND|OR|NOT)(?:\s|$)/.test(q)) throw new Error("暂不支持引号、括号或布尔表达式，请使用简单关键词。");
    const words = [], filters = [];
    for (const token of q.trim().split(/\s+/)) {
      if (token.includes(":")) {
        if (!/^(language:[\w+#.-]+|stars:(?:[<>]=?)?\d+(?:\.\.\d+)?|fork:(?:true|false|only)|archived:(?:true|false)|topic:[a-zA-Z0-9-]+)$/.test(token)) throw new Error("暂不支持此筛选语法；原生结果保持不变。支持 language、stars、fork、archived、topic。");
        filters.push(token);
      } else words.push(token);
    }
    const text = words.join(" ").trim();
    if (!text) throw new Error("请填写项目关键词。");
    return { text, filters };
  }
  function validateEnglish(value) {
    if (typeof value !== "string") throw new Error("模型未返回有效英文关键词。");
    const s = value.trim();
    if (!s || s.length > 160 || hasChinese(s) || /[\r\n:"`{}()[\]<>]/.test(s) || !/[a-zA-Z]/.test(s) || /(?:^|\s)(AND|OR|NOT)(?:\s|$)/.test(s)) throw new Error("模型返回格式无效；请手动输入英文关键词或调整模型。");
    return s;
  }
  class Generation {
    constructor() {
      __publicField(this, "value", 0);
    }
    next() {
      return ++this.value;
    }
    current(n) {
      return n === this.value;
    }
  }
  const versions = new Generation();
  let last = "", host;
  async function rpc(type, data = {}) {
    const r = await chrome.runtime.sendMessage({ type, ...data });
    if (!(r == null ? void 0 : r.ok)) throw new Error((r == null ? void 0 : r.error) || "扩展连接已失效，请刷新页面。");
    return r.data;
  }
  function el(tag, text) {
    const e = document.createElement(tag);
    if (text) e.textContent = text;
    return e;
  }
  function locationQuery() {
    var _a;
    const u = new URL(location.href);
    return u.pathname === "/search" && (!u.searchParams.get("type") || ((_a = u.searchParams.get("type")) == null ? void 0 : _a.toLowerCase()) === "repositories") ? u.searchParams.get("q") || "" : "";
  }
  function mount() {
    const q = locationQuery();
    const identity = location.href;
    if (identity === last && (!hasChinese(q) || (host == null ? void 0 : host.isConnected))) return;
    last = identity;
    versions.next();
    host == null ? void 0 : host.remove();
    host = void 0;
    if (!hasChinese(q)) return;
    const results = document.querySelector('[data-testid="results-list"]');
    const header = document.querySelector('[data-testid="search-sub-header"]');
    const anchor = results || header;
    if (!anchor || !anchor.closest("main")) return;
    const requestVersion = versions.next();
    host = el("section");
    host.id = "github-bilingual-search";
    if (results) results.before(host);
    else header.after(host);
    const root = host.attachShadow({ mode: "open" });
    const css = el("style");
    css.textContent = `
 :host{display:block;margin:0 0 20px;color:var(--fgColor-default,#1f2328);font:14px/1.6 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif} *{box-sizing:border-box} details{border:1px solid var(--borderColor-default,#d1d9e0);border-radius:12px;background:var(--bgColor-default,#fff);overflow:hidden}summary{cursor:pointer;padding:14px 18px;font-weight:650;background:var(--bgColor-muted,#f6f8fa)}.body{padding:16px}form{display:flex;gap:8px;flex-wrap:wrap;margin:10px 0}input{flex:1;min-width:140px}input,button{font:inherit;padding:6px 10px;border:1px solid var(--borderColor-default,#d1d9e0);border-radius:6px;background:var(--bgColor-default,#fff);color:inherit}button{cursor:pointer}button:hover{background:var(--bgColor-muted,#f6f8fa)}a{color:var(--fgColor-accent,#0969da);text-decoration:none}a:hover{text-decoration:underline}.meta,.status{color:var(--fgColor-muted,#59636e);font-size:13px}.error{color:var(--fgColor-danger,#d1242f)}article{border-top:1px solid var(--borderColor-muted,#d8dee4);padding:12px 0}h3{margin:0;font-size:16px}p{margin:5px 0;overflow-wrap:anywhere}.toolbar{display:flex;gap:16px;align-items:center;flex-wrap:wrap} .status{white-space:pre-wrap}`;
    root.append(css);
    const details = el("details");
    details.open = true;
    details.append(el("summary", "英文相关项目 · GitHub 中英搜索"));
    const body = el("div");
    body.className = "body";
    details.append(body);
    root.append(details);
    const status = el("p", "正在转换关键词…");
    status.className = "status";
    status.setAttribute("role", "status");
    status.setAttribute("aria-live", "polite");
    const form = el("form"), input = el("input");
    input.placeholder = "英文关键词，可修改后重新搜索";
    input.setAttribute("aria-label", "英文搜索关键词");
    input.maxLength = 160;
    const submit = el("button", "搜索");
    submit.type = "submit";
    form.append(input, submit);
    const toolbar = el("div");
    toolbar.className = "toolbar";
    const link = el("a", "在 GitHub 打开英文搜索");
    link.target = "_blank";
    link.rel = "noopener noreferrer";
    link.hidden = true;
    const settings = el("button", "设置模型 / 清除缓存");
    settings.type = "button";
    settings.onclick = () => void rpc("openOptions").catch(() => {
    });
    toolbar.append(link, settings);
    const list = el("div");
    body.append(status, form, toolbar, list);
    let sub = 0;
    const active = () => versions.current(requestVersion) && (host == null ? void 0 : host.isConnected) && locationQuery() === q;
    const fail = (e) => {
      status.textContent = e instanceof Error ? e.message : "请求失败，请重试。";
      status.className = "status error";
    };
    const run = async () => {
      const n = ++sub;
      list.replaceChildren();
      link.hidden = true;
      status.textContent = "正在搜索英文项目…";
      status.className = "status";
      try {
        const query = [validateEnglish(input.value), ...parseQuery(q).filters].join(" ");
        link.href = "https://github.com/search?" + new URLSearchParams({ q: query, type: "repositories" });
        link.hidden = false;
        const r = await rpc("search", { original: q, english: input.value });
        if (!active() || n !== sub) return;
        link.href = "https://github.com/search?" + new URLSearchParams({ q: r.query, type: "repositories" });
        link.hidden = false;
        status.textContent = r.repos.length ? `补充 ${r.repos.length} 个项目 · 英文查询：${r.query}` : "本次英文查询没有返回项目，可修改关键词重试。";
        for (const repo of r.repos) {
          const card = el("article"), title = el("h3"), a = el("a", repo.full_name);
          a.href = repo.html_url;
          a.target = "_blank";
          a.rel = "noopener noreferrer";
          title.append(a);
          card.append(title, el("p", repo.description || "暂无项目描述"));
          const meta = el("p", `★ ${Number(repo.stargazers_count).toLocaleString()} · ${repo.language || "未标注语言"}`);
          meta.className = "meta";
          card.append(meta);
          list.append(card);
        }
      } catch (e) {
        if (active() && n === sub) fail(e);
      }
    };
    form.onsubmit = (e) => {
      e.preventDefault();
      void run();
    };
    try {
      parseQuery(q);
    } catch (e) {
      fail(e);
      form.hidden = true;
      return;
    }
    const initialSub = sub;
    void rpc("translate", { query: q }).then((r) => {
      if (!active() || sub !== initialSub) return;
      input.value = r.english;
      input.title = r.source;
      void run();
    }).catch((e) => {
      if (active() && sub === initialSub) fail(e);
    });
  }
  let timer;
  const schedule = () => {
    clearTimeout(timer);
    timer = setTimeout(mount, 180);
  };
  new MutationObserver(schedule).observe(document.documentElement, { childList: true, subtree: true });
  window.addEventListener("popstate", schedule);
  document.addEventListener("turbo:load", schedule);
  document.addEventListener("pjax:end", schedule);
  mount();
})();
